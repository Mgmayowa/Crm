<?php
/**
 * Class for backwards compatibility only
 */

